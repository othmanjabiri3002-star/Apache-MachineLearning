from kafka import KafkaProducer
import time
time.sleep(1)
# Chemin du fichier nettoyé
clean_file = "tweets_clean.txt"

# Initialiser le producteur Kafka
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: v.encode('utf-8')  # convertir le texte en bytes
)

# Nom du topic
topic = "tweets_topic"

# Lire le fichier ligne par ligne et envoyer à Kafka
with open(clean_file, "r", encoding="utf-8") as f:
    for line in f:
        text = line.strip()
        if text:  # ignorer les lignes vides
            producer.send(topic, value=text)
            print(f"Envoyé: {text[:80]}...")  # afficher les 80 premiers caractères
            time.sleep(1.5)  # petit délai pour simuler un flux en temps réel

producer.flush()
print("Tous les tweets ont été envoyés.")
