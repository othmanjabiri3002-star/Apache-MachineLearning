# eval_on_new.py
import os, sys
import joblib, pickle
import pandas as pd, re
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    classification_report, confusion_matrix
)

# === CONFIGURE ===
DATASET_PATH = r"C:/Users/pc/Desktop/Python/project/dataset/kafkadataset.csv"   
MODEL_PATH   = r"C:/Users/pc/Desktop/Python/project/sentiment_model.pkl"
VECT_PATH    = r"C:/Users/pc/Desktop/Python/project/tfidf_vectorizer.pkl"
LE_PATH      = r"C:/Users/pc/Desktop/Python/project/label_encoder.pkl"

# === helper ===
def clean_text(s):
    if pd.isna(s): return ""
    s = str(s).lower()
    s = re.sub(r"http\S+|www\S+|https\S+", '', s)
    s = re.sub(r'@\w+|\#','', s)
    s = re.sub(r'[^A-Za-z0-9\s]+', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def try_joblib(path):
    try:
        obj = joblib.load(path)
        return obj
    except:
        return None

def try_pickle(path):
    try:
        with open(path, "rb") as f:
            return pickle.load(f)
    except:
        return None

def robust_load(path):
    if not os.path.isfile(path):
        print(f"[ERROR] fichier introuvable: {path}")
        return None
    obj = try_joblib(path)
    if obj is not None:
        return obj
    return try_pickle(path)

# === Load model artifacts ===
print("== Chargement des artefacts ==")
model = robust_load(MODEL_PATH)
vectorizer = robust_load(VECT_PATH)
label_encoder = robust_load(LE_PATH)

if model is None or vectorizer is None or label_encoder is None:
    print("\n[ERREUR] Impossible de charger tous les artefacts requis.")
    sys.exit(1)

# === Charger le dataset ===
if not os.path.isfile(DATASET_PATH):
    print(f"[ERREUR] Nouveau dataset introuvable: {DATASET_PATH}")
    sys.exit(1)

df = pd.read_csv(DATASET_PATH)

if 'text' in df.columns.str.lower():
    col_text = [c for c in df.columns if c.lower()=='text'][0]
    col_label = [c for c in df.columns if c.lower()=='label'][0]
else:
    col_text, col_label = df.columns[0], df.columns[1]

print(f"Utilisation des colonnes: text='{col_text}' label='{col_label}'")
df['clean_text'] = df[col_text].astype(str).apply(clean_text)

# Labels
from sklearn.preprocessing import LabelEncoder
if hasattr(label_encoder, 'transform'):
    y_true = label_encoder.transform(df[col_label].astype(str))
else:
    le_new = LabelEncoder()
    y_true = le_new.fit_transform(df[col_label].astype(str))

# Features & prédictions
X_test = vectorizer.transform(df['clean_text'])
y_pred = model.predict(X_test)

# === Évaluation numérique ===
print("\n== Résultats de la performance du modèle ==")
acc = accuracy_score(y_true, y_pred)
prec = precision_score(y_true, y_pred, average="macro")
rec = recall_score(y_true, y_pred, average="macro")
f1 = f1_score(y_true, y_pred, average="macro")

print("Accuracy :", acc)
print("Précision macro :", prec)
print("Recall macro :", rec)
print("F1-score macro :", f1)

cm = confusion_matrix(y_true, y_pred)
print("\nMatrice de confusion :\n", cm)
print("\nRapport de classification :\n", classification_report(y_true, y_pred, target_names=label_encoder.classes_))

# === Visualisation des résultats ===
# Matrice de confusion
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=label_encoder.classes_,
            yticklabels=label_encoder.classes_)
plt.title("Matrice de confusion sur le nouveau dataset")
plt.xlabel("Prédictions")
plt.ylabel("Vérités")
plt.show()

# Comparaison des scores
scores = {"Accuracy": acc, "Précision": prec, "Recall": rec, "F1-score": f1}
plt.figure(figsize=(6, 4))
sns.barplot(x=list(scores.keys()), y=list(scores.values()), palette="viridis")
plt.title("Scores de performance du modèle sur le nouveau dataset")
plt.ylim(0, 1)
plt.show()
