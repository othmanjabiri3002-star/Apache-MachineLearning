# consumer.py
import os
from kafka import KafkaConsumer
import joblib
import re

# --- Configuration des chemins
MODEL_PATH = r"C:/Users/pc/Desktop/Python/project/sentiment_model.pkl"
VECT_PATH  = r"C:/Users/pc/Desktop/Python/project/tfidf_vectorizer.pkl"
LE_PATH    = r"C:/Users/pc/Desktop/Python/project/label_encoder.pkl"
TOPIC      = "tweets_topic"
BOOTSTRAP  = "localhost:9092"

# --- Vérifier que les fichiers existent
for p in (MODEL_PATH, VECT_PATH, LE_PATH):
    if not os.path.isfile(p):
        print(f"[ERREUR] Fichier introuvable : {p}")
        exit(1)

# --- Charger les fichiers
try:
    model = joblib.load(MODEL_PATH)
    vectorizer = joblib.load(VECT_PATH)
    label_encoder = joblib.load(LE_PATH)
except Exception as e:
    print("[ERREUR] Impossible de charger les fichiers de modèle/vectorizer/encoder :")
    print(e)
    exit(1)

print("Modèle, vectorizer et label encoder chargés avec succès.")

# --- Fonction de nettoyage du texte
def clean_text(text):
    if text is None:
        return ""
    text = text.lower()
    text = re.sub(r"http\S+", "", text)
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#", "", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# --- Créer le consumer Kafka
consumer = KafkaConsumer(
    TOPIC,
    bootstrap_servers=BOOTSTRAP,
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    group_id='sentiment-group',
    value_deserializer=lambda v: v.decode('utf-8')  # texte brut
)

# --- Reconstruction du mapping label numérique -> texte
label_map = {i: cls for i, cls in enumerate(label_encoder.classes_)}

print(f"En écoute sur le topic '{TOPIC}'...")

# --- Boucle de consommation et prédiction
for msg in consumer:
    try:
        raw_text = msg.value
        text = clean_text(raw_text)
        X = vectorizer.transform([text])
        pred_num = model.predict(X)[0]
        pred_label = label_map.get(pred_num, str(pred_num))
        print(f"Texte: {raw_text[:200]}")
        print(f"Prédiction: {pred_label}")
        print("-"*80)
    except Exception as e:
        print("[ERREUR pendant traitement d'un message]:", e)
