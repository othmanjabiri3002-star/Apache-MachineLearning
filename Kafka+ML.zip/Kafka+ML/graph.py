import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    classification_report, confusion_matrix
)
import re
from tqdm import tqdm
import joblib  
import matplotlib.pyplot as plt
import seaborn as sns

#  Chargement du dataset
df = pd.read_csv("C:/Users/pc/Desktop/Python/project/dataset/twittersentimentanalysis.csv")  
df = df[['Text', 'Label']]

#  Nettoyage du texte
def clean_text(text):
    if pd.isna(text):
        return ""
    text = text.lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'@\w+', '', text)
    text = re.sub(r'#', '', text)
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

tqdm.pandas(desc="Cleaning tweets")
df['Text'] = df['Text'].progress_apply(clean_text)

#  Remplacer labels textuels par des chiffres
le = LabelEncoder()
df['Label'] = le.fit_transform(df['Label'])

#  Séparation train + validation + test
X_temp, X_test, y_temp, y_test = train_test_split(
    df['Text'], df['Label'], test_size=0.2, random_state=42, stratify=df['Label']
)
X_train, X_valid, y_train, y_valid = train_test_split(
    X_temp, y_temp, test_size=0.1, random_state=42, stratify=y_temp
)

print(f"Train size: {len(X_train)}, Validation size: {len(X_valid)}, Test size: {len(X_test)}")

# Vectorisation TF-IDF
vectorizer = TfidfVectorizer(max_features=10000, ngram_range=(1,2))
X_train_vect = vectorizer.fit_transform(X_train)
X_valid_vect = vectorizer.transform(X_valid)
X_test_vect = vectorizer.transform(X_test)

#  Entraînement du modèle
model = LogisticRegression(max_iter=1000, verbose=1)
model.fit(X_train_vect, y_train)

#  Fonction d’évaluation avec graphiques
def evaluate_model(model, X, y, dataset_name="Dataset"):
    y_pred = model.predict(X)
    
    # Scores
    acc = accuracy_score(y, y_pred)
    prec = precision_score(y, y_pred, average='weighted', zero_division=0)
    rec = recall_score(y, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y, y_pred, average='weighted', zero_division=0)

    print(f"\n------------------ Performance sur {dataset_name} -------------------")
    print("Accuracy :", acc)
    print("Precision:", prec)
    print("Recall   :", rec)
    print("F1 Score :", f1)
    print("\nClassification Report:\n", classification_report(y, y_pred, zero_division=0))
    
    # Matrice de confusion
    cm = confusion_matrix(y, y_pred)
    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=le.classes_, yticklabels=le.classes_)
    plt.title(f"Matrice de confusion - {dataset_name}")
    plt.xlabel("Prédictions")
    plt.ylabel("Vérités")
    plt.show()

    return {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1}

# Évaluation sur les trois jeux
results_train = evaluate_model(model, X_train_vect, y_train, "Train")
results_valid = evaluate_model(model, X_valid_vect, y_valid, "Validation")
results_test = evaluate_model(model, X_test_vect, y_test, "Test")

# Comparaison des scores
results_df = pd.DataFrame([results_train, results_valid, results_test],
                          index=["Train", "Validation", "Test"])

results_df.plot(kind="bar", figsize=(8, 5))
plt.title("Comparaison des performances du modèle")
plt.ylabel("Score")
plt.ylim(0.9, 1.0)  # car ton modèle est très performant
plt.xticks(rotation=0)
plt.legend(loc="lower right")
plt.show()

#  Enregistrer le modèle et le vectoriseur
joblib.dump(model, "sentiment_modele.pkl")
joblib.dump(vectorizer, "tfidf_vectorizere.pkl")
joblib.dump(le, "label_encodere.pkl")
print("\n Le Modèle, vectoriseur et encodeur sauvegardés avec succès !")
